Hello!

This game is based on Donkey Kong Gameplay, specifically Arcade Edition with four levels. I used King Kong as Mario, and the other kaijus as Donkey Kong.
Barrels are the Beams coming from the kaijus on top of the platform and flames are replaced by the rocks.

To start the game, you have to start from main.py which imports all the level files.
I used a 1920x1080 monitor for the game.
There is an option where if you want to try out other levels without playing the arcade game, you can play each level individually.
If you want to look at the stuff that were added, you can search for the assets and look for something that you are curious about.

The gameplay (test run) was recorded which can be found in the testing folder.


joystick should be similar dpad will control the movement
Controller we used was 8bitido

CONTROLS:

left - left arrow (left)
right - right arrow (left)
climb up - up arrow (left)
climb down - down arrow (left)
jump - space  (X)
restart level - r (+)
quit - q (-)
